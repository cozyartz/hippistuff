import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  Leaf, 
  Users, 
  BookOpen, 
  Play, 
  MessageCircle,
  Calendar,
  Download,
  Mail,
  Menu,
  X,
  ArrowRight,
  Star,
  Globe,
  Recycle,
  Award,
  User,
  MapPin,
  Clock,
  CheckCircle,
  Camera,
  Headphones,
  FileText,
  Video,
  Coffee,
  Flower,
  Sun,
  Moon,
  Zap,
  TreePine,
  Wind,
  Droplets,
  Instagram,
  Youtube,
  Facebook,
  Twitter,
  Feather,
  Mountain,
  Waves,
  Lightbulb,
  Scissors,
  Palette,
  Hammer,
  Sprout
} from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrollY, setScrollY] = useState(0);
  const [email, setEmail] = useState('');
  const [activeTab, setActiveTab] = useState('blog');

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
    setIsMenuOpen(false);
  };

  const handleNewsletterSignup = (e: React.FormEvent) => {
    e.preventDefault();
    // Newsletter signup logic would go here
    alert('Welcome to the community! 🌱');
    setEmail('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-amber-50">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrollY > 50 ? 'bg-white/95 backdrop-blur-sm shadow-sm border-b border-green-100' : 'bg-transparent'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-green-600 to-emerald-700 rounded-full flex items-center justify-center">
                <Leaf className="w-6 h-6 text-white stroke-1" />
              </div>
              <span className="text-2xl font-light bg-gradient-to-r from-green-700 to-emerald-600 bg-clip-text text-transparent">
                HippieStuff
              </span>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <button onClick={() => scrollToSection('content')} className="text-gray-700 hover:text-green-600 transition-colors font-light">
                Explore
              </button>
              <button onClick={() => scrollToSection('community')} className="text-gray-700 hover:text-green-600 transition-colors font-light">
                Community
              </button>
              <button onClick={() => scrollToSection('education')} className="text-gray-700 hover:text-green-600 transition-colors font-light">
                Learn
              </button>
              <button onClick={() => scrollToSection('newsletter')} className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-6 py-2 rounded-full hover:shadow-md transition-all font-light">
                Join Us
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-green-50 transition-colors"
            >
              {isMenuOpen ? <X className="w-6 h-6 stroke-1" /> : <Menu className="w-6 h-6 stroke-1" />}
            </button>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="md:hidden bg-white/95 backdrop-blur-sm border-t border-green-100">
              <div className="px-4 py-6 space-y-4">
                <button onClick={() => scrollToSection('content')} className="block w-full text-left text-gray-700 hover:text-green-600 transition-colors font-light">
                  Explore
                </button>
                <button onClick={() => scrollToSection('community')} className="block w-full text-left text-gray-700 hover:text-green-600 transition-colors font-light">
                  Community
                </button>
                <button onClick={() => scrollToSection('education')} className="block w-full text-left text-gray-700 hover:text-green-600 transition-colors font-light">
                  Learn
                </button>
                <button onClick={() => scrollToSection('newsletter')} className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-6 py-2 rounded-full hover:shadow-md transition-all w-full font-light">
                  Join Us
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-20 pb-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        {/* Floating Elements */}
        <div className="absolute top-32 left-10 w-20 h-20 opacity-10">
          <TreePine className="w-full h-full text-green-600 stroke-1" />
        </div>
        <div className="absolute top-40 right-16 w-16 h-16 opacity-10">
          <Flower className="w-full h-full text-amber-600 stroke-1" />
        </div>
        <div className="absolute bottom-20 left-20 w-24 h-24 opacity-10">
          <Mountain className="w-full h-full text-blue-600 stroke-1" />
        </div>
        
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <div className="relative inline-block">
              <h1 className="text-5xl md:text-7xl font-light bg-gradient-to-r from-green-700 via-blue-600 to-amber-700 bg-clip-text text-transparent mb-6 leading-tight">
                Peace, Love & 
                <br />
                Real Change
              </h1>
            </div>
            
            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed font-light">
              Welcome to the online home for modern hippies, eco-enthusiasts, and anyone passionate about living sustainably. 
              Dive into practical tips, creative DIYs, and the latest in hippie-inspired culture. Connect with a community that 
              cares about the planet—and having fun while making a difference.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
              <button 
                onClick={() => scrollToSection('community')}
                className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-8 py-4 rounded-full text-lg font-light hover:shadow-lg transition-all transform hover:scale-105 flex items-center gap-2"
              >
                <Users className="w-5 h-5 stroke-1" />
                Join the Community
              </button>
              <button 
                onClick={() => scrollToSection('content')}
                className="border-2 border-green-600 text-green-600 px-8 py-4 rounded-full text-lg font-light hover:bg-green-600 hover:text-white transition-all flex items-center gap-2"
              >
                <ArrowRight className="w-5 h-5 stroke-1" />
                Start Exploring
              </button>
            </div>

            {/* Nature-inspired decorative elements */}
            <div className="flex justify-center items-center gap-8 opacity-30">
              <Leaf className="w-8 h-8 text-green-600 stroke-1" />
              <div className="w-2 h-2 bg-green-600 rounded-full"></div>
              <Sun className="w-8 h-8 text-amber-600 stroke-1" />
              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              <Waves className="w-8 h-8 text-blue-600 stroke-1" />
            </div>
          </div>
        </div>
      </section>

      {/* Content Hub Section */}
      <section id="content" className="py-20 px-4 sm:px-6 lg:px-8 bg-white/60 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="flex justify-center mb-4">
              <BookOpen className="w-12 h-12 text-green-600 stroke-1" />
            </div>
            <h2 className="text-4xl md:text-5xl font-light text-gray-800 mb-6">
              Explore & Create
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto font-light">
              Practical guides, creative projects, and real-world tips for sustainable living and modern hippie culture
            </p>
          </div>

          {/* Content Tabs */}
          <div className="flex flex-wrap justify-center mb-12 gap-4">
            {[
              { id: 'blog', label: 'Sustainable Living', icon: Sprout },
              { id: 'videos', label: 'DIY Projects', icon: Hammer },
              { id: 'guides', label: 'Community Events', icon: MapPin },
              { id: 'diy', label: 'Creative Culture', icon: Palette }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-6 py-3 rounded-full transition-all font-light ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-green-600 to-emerald-600 text-white shadow-md'
                    : 'bg-white/80 text-gray-700 hover:bg-white border border-green-100'
                }`}
              >
                <tab.icon className="w-5 h-5 stroke-1" />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Content Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Zero-Waste Kitchen Hacks That Actually Work",
                category: "Sustainable Living",
                image: "https://images.pexels.com/photos/4099464/pexels-photo-4099464.jpeg?auto=compress&cs=tinysrgb&w=600",
                author: "Maya Green",
                date: "2 days ago",
                readTime: "6 min read"
              },
              {
                title: "DIY Natural Dye Workshop: From Garden to Fabric",
                category: "Creative Projects",
                image: "https://images.pexels.com/photos/4321186/pexels-photo-4321186.jpeg?auto=compress&cs=tinysrgb&w=600",
                author: "River Stone",
                date: "1 week ago",
                readTime: "12 min read"
              },
              {
                title: "Building Community Gardens in Urban Spaces",
                category: "Community Action",
                image: "https://images.pexels.com/photos/1301856/pexels-photo-1301856.jpeg?auto=compress&cs=tinysrgb&w=600",
                author: "Urban Farmer",
                date: "3 days ago",
                readTime: "8 min read"
              },
              {
                title: "Thrift Flipping: Vintage Style on a Budget",
                category: "Sustainable Fashion",
                image: "https://images.pexels.com/photos/3965545/pexels-photo-3965545.jpeg?auto=compress&cs=tinysrgb&w=600",
                author: "Vintage Vibes",
                date: "5 days ago",
                readTime: "10 min read"
              },
              {
                title: "Plastic-Free Living: A Realistic 30-Day Challenge",
                category: "Eco Challenge",
                image: "https://images.pexels.com/photos/3850512/pexels-photo-3850512.jpeg?auto=compress&cs=tinysrgb&w=600",
                author: "Eco Warrior",
                date: "1 week ago",
                readTime: "7 min read"
              },
              {
                title: "Festival Season: Sustainable Camping Tips",
                category: "Hippie Culture",
                image: "https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=600",
                author: "Festival Guide",
                date: "4 days ago",
                readTime: "9 min read"
              }
            ].map((item, index) => (
              <div key={index} className="bg-white/80 backdrop-blur-sm rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all transform hover:-translate-y-1 group border border-green-50">
                <div className="relative">
                  <img 
                    src={item.image} 
                    alt={item.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-white/90 backdrop-blur-sm text-green-700 px-3 py-1 rounded-full text-sm font-light border border-green-100">
                      {item.category}
                    </span>
                  </div>
                  <div className="absolute top-4 right-4">
                    <button className="bg-white/90 backdrop-blur-sm p-2 rounded-full hover:bg-white transition-colors border border-green-100">
                      <Heart className="w-4 h-4 text-gray-600 stroke-1" />
                    </button>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-light text-gray-800 mb-3 group-hover:text-green-700 transition-colors leading-tight">
                    {item.title}
                  </h3>
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4 font-light">
                    <div className="flex items-center gap-2">
                      <Feather className="w-4 h-4 stroke-1" />
                      {item.author}
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 stroke-1" />
                      {item.readTime}
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500 font-light">{item.date}</span>
                    <button className="text-green-600 font-light hover:text-green-800 transition-colors flex items-center gap-1">
                      Read More
                      <ArrowRight className="w-4 h-4 stroke-1" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-8 py-4 rounded-full text-lg font-light hover:shadow-lg transition-all transform hover:scale-105">
              Explore All Content
            </button>
          </div>
        </div>
      </section>

      {/* Community Platform Section */}
      <section id="community" className="py-20 px-4 sm:px-6 lg:px-8 relative">
        {/* Background decorative elements */}
        <div className="absolute top-10 right-10 w-32 h-32 opacity-5">
          <Sun className="w-full h-full text-amber-600 stroke-1" />
        </div>
        <div className="absolute bottom-10 left-10 w-28 h-28 opacity-5">
          <TreePine className="w-full h-full text-green-600 stroke-1" />
        </div>
        
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="flex justify-center mb-4">
              <Users className="w-12 h-12 text-blue-600 stroke-1" />
            </div>
            <h2 className="text-4xl md:text-5xl font-light text-gray-800 mb-6">
              Join the Movement
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto font-light">
              Connect with like-minded people who are passionate about sustainability, creativity, and positive change
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Community Features */}
            <div className="space-y-8">
              <div className="flex items-start gap-4 p-6 bg-white/60 backdrop-blur-sm rounded-2xl shadow-sm hover:shadow-md transition-all border border-green-50">
                <div className="bg-gradient-to-br from-blue-500 to-blue-600 p-3 rounded-full">
                  <MessageCircle className="w-6 h-6 text-white stroke-1" />
                </div>
                <div>
                  <h3 className="text-xl font-light text-gray-800 mb-2">Discussion Forums</h3>
                  <p className="text-gray-600 font-light">
                    Share tips, ask questions, and connect with others on sustainable living, DIY projects, and eco-friendly lifestyle choices
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-6 bg-white/60 backdrop-blur-sm rounded-2xl shadow-sm hover:shadow-md transition-all border border-green-50">
                <div className="bg-gradient-to-br from-green-500 to-emerald-600 p-3 rounded-full">
                  <Calendar className="w-6 h-6 text-white stroke-1" />
                </div>
                <div>
                  <h3 className="text-xl font-light text-gray-800 mb-2">Local Events & Meetups</h3>
                  <p className="text-gray-600 font-light">
                    Find eco-friendly events, sustainability workshops, and community gatherings happening near you
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-6 bg-white/60 backdrop-blur-sm rounded-2xl shadow-sm hover:shadow-md transition-all border border-green-50">
                <div className="bg-gradient-to-br from-amber-500 to-orange-500 p-3 rounded-full">
                  <Award className="w-6 h-6 text-white stroke-1" />
                </div>
                <div>
                  <h3 className="text-xl font-light text-gray-800 mb-2">Impact Tracking</h3>
                  <p className="text-gray-600 font-light">
                    Track your sustainable actions, earn badges, and see the collective impact our community is making
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-6 bg-white/60 backdrop-blur-sm rounded-2xl shadow-sm hover:shadow-md transition-all border border-green-50">
                <div className="bg-gradient-to-br from-purple-500 to-indigo-500 p-3 rounded-full">
                  <Star className="w-6 h-6 text-white stroke-1" />
                </div>
                <div>
                  <h3 className="text-xl font-light text-gray-800 mb-2">Project Sharing</h3>
                  <p className="text-gray-600 font-light">
                    Show off your DIY creations, upcycling projects, and sustainable lifestyle wins with the community
                  </p>
                </div>
              </div>
            </div>

            {/* Community Testimonials */}
            <div className="space-y-8">
              <div className="bg-gradient-to-br from-green-600 to-emerald-700 p-8 rounded-2xl text-white">
                <div className="flex justify-center mb-6">
                  <Heart className="w-8 h-8 text-white stroke-1" />
                </div>
                <h3 className="text-2xl font-light mb-6 text-center">Real Community Impact</h3>
                <p className="text-green-100 text-center font-light leading-relaxed">
                  "This community has completely changed how I approach sustainability. The practical tips and supportive people make living eco-friendly actually achievable and fun!"
                </p>
                <div className="text-center mt-6">
                  <div className="font-light text-green-100">— Sarah M., Community Member</div>
                </div>
              </div>

              {/* Additional testimonials */}
              <div className="space-y-4">
                <div className="bg-white/60 backdrop-blur-sm p-6 rounded-2xl shadow-sm border border-blue-50">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-500 rounded-full flex items-center justify-center">
                      <Recycle className="w-6 h-6 text-white stroke-1" />
                    </div>
                    <div>
                      <div className="font-light text-gray-800">Alex R.</div>
                      <div className="text-sm text-gray-500 font-light">Zero-Waste Enthusiast</div>
                    </div>
                  </div>
                  <p className="text-gray-600 font-light italic">
                    "Found amazing local events through this platform! Met so many cool people who share my passion for environmental action. 🌱"
                  </p>
                </div>

                <div className="bg-white/60 backdrop-blur-sm p-6 rounded-2xl shadow-sm border border-amber-50">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full flex items-center justify-center">
                      <Lightbulb className="w-6 h-6 text-white stroke-1" />
                    </div>
                    <div>
                      <div className="font-light text-gray-800">Jamie L.</div>
                      <div className="text-sm text-gray-500 font-light">DIY Creator</div>
                    </div>
                  </div>
                  <p className="text-gray-600 font-light italic">
                    "The DIY project ideas here are incredible! I've saved so much money and reduced waste by making my own stuff. Love this community! ✨"
                  </p>
                </div>
              </div>

              <button className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white px-8 py-4 rounded-full text-lg font-light hover:shadow-lg transition-all transform hover:scale-105">
                Join Our Community
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Educational Resources Section */}
      <section id="education" className="py-20 px-4 sm:px-6 lg:px-8 bg-white/60 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="flex justify-center mb-4">
              <BookOpen className="w-12 h-12 text-amber-600 stroke-1" />
            </div>
            <h2 className="text-4xl md:text-5xl font-light text-gray-800 mb-6">
              Learn & Grow
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto font-light">
              Practical courses, workshops, and resources to help you live more sustainably and make a real difference
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 mb-16">
            {/* Learning Paths */}
            <div className="lg:col-span-2">
              <h3 className="text-2xl font-light text-gray-800 mb-6">Popular Learning Paths</h3>
              <div className="space-y-6">
                {[
                  {
                    title: "Sustainable Living Essentials",
                    description: "Master the basics of eco-friendly living with practical, actionable steps you can start today",
                    modules: 8,
                    duration: "4 weeks",
                    level: "Beginner",
                    color: "from-green-500 to-emerald-600",
                    icon: Leaf
                  },
                  {
                    title: "DIY & Upcycling Mastery",
                    description: "Learn to transform waste into wonderful creations while saving money and reducing environmental impact",
                    modules: 12,
                    duration: "6 weeks",
                    level: "All Levels",
                    color: "from-blue-500 to-indigo-600",
                    icon: Hammer
                  },
                  {
                    title: "Community Building & Activism",
                    description: "Discover how to create positive change in your community and inspire others to join the movement",
                    modules: 10,
                    duration: "5 weeks",
                    level: "Intermediate",
                    color: "from-amber-500 to-orange-600",
                    icon: Users
                  }
                ].map((path, index) => (
                  <div key={index} className="bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-sm hover:shadow-md transition-all group border border-green-50">
                    <div className="flex items-start gap-4">
                      <div className={`bg-gradient-to-br ${path.color} p-3 rounded-full group-hover:scale-110 transition-transform`}>
                        <path.icon className="w-6 h-6 text-white stroke-1" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="text-xl font-light text-gray-800">{path.title}</h4>
                          <span className="bg-green-50 text-green-700 px-3 py-1 rounded-full text-sm font-light border border-green-100">
                            {path.level}
                          </span>
                        </div>
                        <p className="text-gray-600 mb-4 font-light">{path.description}</p>
                        <div className="flex items-center gap-4 text-sm text-gray-500 mb-4 font-light">
                          <div className="flex items-center gap-1">
                            <BookOpen className="w-4 h-4 stroke-1" />
                            {path.modules} lessons
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4 stroke-1" />
                            {path.duration}
                          </div>
                        </div>
                        <button className="text-green-600 font-light hover:text-green-800 transition-colors flex items-center gap-1">
                          Start Learning
                          <ArrowRight className="w-4 h-4 stroke-1" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Upcoming Workshops */}
            <div>
              <h3 className="text-2xl font-light text-gray-800 mb-6">Upcoming Workshops</h3>
              <div className="space-y-4">
                {[
                  {
                    title: "Zero-Waste Kitchen Bootcamp",
                    date: "Tomorrow, 7 PM EST",
                    host: "Chef Maya",
                    type: "Live Workshop"
                  },
                  {
                    title: "Upcycling Furniture 101",
                    date: "Friday, 6 PM EST",
                    host: "DIY Dan",
                    type: "Hands-on Session"
                  },
                  {
                    title: "Natural Beauty Products",
                    date: "Saturday, 3 PM EST",
                    host: "Green Beauty",
                    type: "DIY Workshop"
                  },
                  {
                    title: "Community Garden Planning",
                    date: "Sunday, 5 PM EST",
                    host: "Urban Farmer",
                    type: "Planning Session"
                  }
                ].map((workshop, index) => (
                  <div key={index} className="bg-white/80 backdrop-blur-sm p-4 rounded-xl shadow-sm hover:shadow-md transition-all border border-blue-50">
                    <h4 className="font-light text-gray-800 mb-2">{workshop.title}</h4>
                    <div className="text-sm text-gray-500 space-y-1 font-light">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 stroke-1" />
                        {workshop.date}
                      </div>
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 stroke-1" />
                        {workshop.host}
                      </div>
                      <div className="flex items-center gap-2">
                        <Star className="w-4 h-4 stroke-1" />
                        {workshop.type}
                      </div>
                    </div>
                    <button className="w-full mt-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white py-2 rounded-lg text-sm font-light hover:shadow-md transition-all">
                      Join Workshop
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Free Resources */}
          <div className="bg-gradient-to-br from-green-600 to-emerald-700 p-8 rounded-2xl text-white">
            <div className="flex justify-center mb-6">
              <Download className="w-8 h-8 text-white stroke-1" />
            </div>
            <h3 className="text-2xl font-light mb-6 text-center">Free Resources</h3>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                {
                  title: "Sustainable Living Starter Guide",
                  description: "50+ practical tips to begin your eco-friendly journey",
                  downloads: "25K downloads",
                  icon: CheckCircle
                },
                {
                  title: "DIY Natural Cleaning Recipes",
                  description: "Safe, effective recipes for a chemical-free home",
                  downloads: "18K downloads",
                  icon: Droplets
                },
                {
                  title: "Zero-Waste Challenge Tracker",
                  description: "30-day challenge with daily actions and progress tracking",
                  downloads: "32K downloads",
                  icon: Recycle
                }
              ].map((resource, index) => (
                <div key={index} className="bg-white/10 backdrop-blur-sm p-6 rounded-xl hover:bg-white/20 transition-all">
                  <resource.icon className="w-8 h-8 text-white mb-4 stroke-1" />
                  <h4 className="text-lg font-light mb-2">{resource.title}</h4>
                  <p className="text-green-100 text-sm mb-4 font-light">{resource.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-green-200 font-light">{resource.downloads}</span>
                    <button className="flex items-center gap-2 bg-white text-green-700 px-4 py-2 rounded-lg text-sm font-light hover:bg-green-50 transition-colors">
                      <Download className="w-4 h-4 stroke-1" />
                      Download
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section id="newsletter" className="py-20 px-4 sm:px-6 lg:px-8 relative">
        {/* Background decorative elements */}
        <div className="absolute top-20 left-20 w-24 h-24 opacity-5">
          <Flower className="w-full h-full text-amber-600 stroke-1" />
        </div>
        <div className="absolute bottom-20 right-20 w-20 h-20 opacity-5">
          <Heart className="w-full h-full text-green-600 stroke-1" />
        </div>
        
        <div className="max-w-4xl mx-auto text-center">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-green-600 to-emerald-700 rounded-3xl opacity-10"></div>
            <div className="relative bg-white/80 backdrop-blur-sm p-12 rounded-3xl shadow-lg border border-green-100">
              <div className="flex justify-center mb-6">
                <div className="bg-gradient-to-br from-green-600 to-emerald-700 p-4 rounded-full">
                  <Mail className="w-8 h-8 text-white stroke-1" />
                </div>
              </div>
              
              <h2 className="text-4xl font-light text-gray-800 mb-6">
                Stay Connected
              </h2>
              <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto font-light leading-relaxed">
                Get weekly inspiration, practical tips, DIY projects, and community highlights delivered straight to your inbox. 
                Join thousands of eco-enthusiasts making a difference every day.
              </p>

              <form onSubmit={handleNewsletterSignup} className="max-w-md mx-auto">
                <div className="flex gap-4">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email address"
                    className="flex-1 px-6 py-4 rounded-full border border-green-200 focus:outline-none focus:ring-2 focus:ring-green-600 focus:border-transparent text-lg font-light bg-white/90 backdrop-blur-sm"
                    required
                  />
                  <button
                    type="submit"
                    className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-8 py-4 rounded-full text-lg font-light hover:shadow-lg transition-all transform hover:scale-105 whitespace-nowrap"
                  >
                    Join Us
                  </button>
                </div>
              </form>

              <div className="flex items-center justify-center gap-6 mt-6 text-sm text-gray-500 font-light">
                <div className="flex items-center gap-1">
                  <CheckCircle className="w-4 h-4 text-green-500 stroke-1" />
                  No spam, ever
                </div>
                <div className="flex items-center gap-1">
                  <CheckCircle className="w-4 h-4 text-green-500 stroke-1" />
                  Unsubscribe anytime
                </div>
                <div className="flex items-center gap-1">
                  <CheckCircle className="w-4 h-4 text-green-500 stroke-1" />
                  Weekly inspiration
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-800 to-gray-900 text-white py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            {/* Brand */}
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-br from-green-600 to-emerald-700 rounded-full flex items-center justify-center">
                  <Leaf className="w-6 h-6 text-white stroke-1" />
                </div>
                <span className="text-2xl font-light">HippieStuff</span>
              </div>
              <p className="text-gray-300 text-lg leading-relaxed max-w-md font-light">
                Empowering modern hippies and eco-enthusiasts to live sustainably, 
                create positive change, and build community. Together, we're making 
                the world a better place, one conscious choice at a time.
              </p>
              <div className="flex space-x-4 mt-6">
                <button className="bg-gray-700 p-3 rounded-full hover:bg-green-600 transition-colors">
                  <Instagram className="w-5 h-5 stroke-1" />
                </button>
                <button className="bg-gray-700 p-3 rounded-full hover:bg-red-600 transition-colors">
                  <Youtube className="w-5 h-5 stroke-1" />
                </button>
                <button className="bg-gray-700 p-3 rounded-full hover:bg-blue-600 transition-colors">
                  <Facebook className="w-5 h-5 stroke-1" />
                </button>
                <button className="bg-gray-700 p-3 rounded-full hover:bg-blue-400 transition-colors">
                  <Twitter className="w-5 h-5 stroke-1" />
                </button>
              </div>
            </div>

            {/* Explore */}
            <div>
              <h4 className="text-lg font-light mb-6">Explore</h4>
              <ul className="space-y-3 text-gray-300 font-light">
                <li><button onClick={() => scrollToSection('content')} className="hover:text-green-400 transition-colors">Sustainable Living</button></li>
                <li><button onClick={() => scrollToSection('community')} className="hover:text-green-400 transition-colors">Community</button></li>
                <li><button onClick={() => scrollToSection('education')} className="hover:text-green-400 transition-colors">Learn & Grow</button></li>
                <li><button onClick={() => scrollToSection('newsletter')} className="hover:text-green-400 transition-colors">Newsletter</button></li>
              </ul>
            </div>

            {/* Support */}
            <div>
              <h4 className="text-lg font-light mb-6">Support</h4>
              <ul className="space-y-3 text-gray-300 font-light">
                <li><a href="#" className="hover:text-green-400 transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-green-400 transition-colors">Community Guidelines</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-8">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <p className="text-gray-400 text-center font-light">
                © 2025 HippieStuff.com. Made with 🌱 for the planet and community.
              </p>
              <div className="flex items-center gap-4 mt-4 md:mt-0 text-gray-400 font-light">
                <Leaf className="w-4 h-4 stroke-1" />
                <span>Creating positive change together</span>
                <Heart className="w-4 h-4 stroke-1" />
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;